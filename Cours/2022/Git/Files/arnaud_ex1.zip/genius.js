function add(number1, number2)
{
    return number1 + number2;
}

function substract(number1, number2)
{
    return number1 - number2;
}

function multiply(number1, number2)
{
    return number1 * number2
}
function divide(number1, number2)
{
    return number1 / number2
}